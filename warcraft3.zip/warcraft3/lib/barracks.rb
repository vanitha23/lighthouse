class Barracks

  def can_train_footman?
    true
  end
end
